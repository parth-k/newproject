jQuery(document).ready(function($) {  $('select.multiselect').multiselect({    includeSelectAllOption: true,    nonSelectedText: 'Select Class'  });});
