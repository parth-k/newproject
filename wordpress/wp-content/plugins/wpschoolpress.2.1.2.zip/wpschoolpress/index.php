<?php
if (!defined( 'ABSPATH' ) )exit('No Such File'); 
die('No File/directory exist');
?>