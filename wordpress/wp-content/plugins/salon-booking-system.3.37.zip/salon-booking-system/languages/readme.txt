********************************************************

  Salon Booking System I18n
  ============================
  
  Do not put your custom translations here. They will be deleted
  on Salon booking system  updates.
  
  Keep custom salon-booking-system translations in /wp-content/languages/plugins/
  
  If you want to translate, help, or improve a translation please visit:

  https://www.transifex.com/projects/p/salon-booking-system/

  

  

********************************************************
