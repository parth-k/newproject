<p><strong><?php _e('Venue Tags', 'event_espresso'); ?></strong></p>
<p>
<?php _e('You can setup tags for your venue. This is optional. To add a tag, enter it into the tag field and click on the Add button.', 'event_espresso'); ?>
</p>
<p><strong><?php _e('Venue Categories', 'event_espresso'); ?></strong></p>
<p>
<?php _e('You can setup categories for your venue. This is optional. To add a venue category, select one from the tabs or click on the add new category link and enter a name for your venue category and click on the add new category button.', 'event_espresso'); ?>
</p>