<div class="padding">
    <!-- <p><?php _e(
        'Download the <a href="https://eventespresso.com/wp-content/plugins/download-monitor/download.php?id=2">Installation Guide</a> as a PDF',
        'event_espresso'
    ); ?></p> -->
    <p>
        <?php _e('For the latest installation instructions please visit:', 'event_espresso'); ?>
        <a href="https://eventespresso.com/wiki/installing-event-espresso/" target="_blank">https://eventespresso.com/wiki/installing-event-espresso/</a>
    </p>
</div>