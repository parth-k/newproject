<p><strong><?php _e('Bulk Actions', 'event_espresso'); ?></strong></p>
<p>
<?php _e('Bulk actions allow you to perform an action to multiple Message Types at once. The following bulk actions are supported: Move to Trash. To use the bulk action feature, place a checkmark next to the message types that you want to include. Then select a bulk action from the menu and click on the Apply button.', 'event_espresso'); ?>
</p>