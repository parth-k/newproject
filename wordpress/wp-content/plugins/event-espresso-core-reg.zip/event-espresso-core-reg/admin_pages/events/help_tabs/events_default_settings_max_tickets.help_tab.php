<p>
    <?php esc_html_e(
        'Use this to control what the default will be for maximum tickets on an order when creating a new event.',
        'event_espresso'
    ); ?>
</p>