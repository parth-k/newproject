<h1><span class="small-text not-bold">
        <?php _e(
            'Adding Registration For: ',
            'event_espresso'
        ); ?></span><?php echo $event_name; ?></h1>
<?php echo $step_content;
