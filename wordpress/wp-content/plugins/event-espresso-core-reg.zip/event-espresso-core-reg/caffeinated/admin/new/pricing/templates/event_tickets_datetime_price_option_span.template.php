<section id="price-option-<?php echo $PRT_ID; ?>">
    <span class="ee-price-operator hidden"><?php echo $PRT_operator; ?></span><span
        class="ee-PRT_is_percent hidden"><?php echo $PRT_is_percent; ?></span>
</section>
<?php
/**
 * template args in use
 *
 * $PRT_ID
 * $PRT_operator
 * $PRT_is_percent
 */
