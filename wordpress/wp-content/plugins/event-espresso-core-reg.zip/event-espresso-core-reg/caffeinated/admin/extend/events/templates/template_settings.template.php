<?php
/**
 * Template for General Settings Template Tab
 */
?>
<div class="padding">

    <?php do_action('AHEE__template_settings__template__before_settings_form'); ?>

</div>
