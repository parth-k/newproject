<?php
/** There are no droids here. Move along. */
