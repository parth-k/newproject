<h4><a href="[EDIT_ATTENDEE_LINK]">[FNAME] [LNAME]</a></h4>
        <ul>
<li><strong><?php _e('Registration Code:', 'event_espresso'); ?></strong> <a href="[EDIT_ATTENDEE_LINK]">[REGISTRATION_CODE]</a></li>
<li><strong><?php _e('Tickets:', 'event_espresso'); ?></strong></li>
</ul>
<ul>[TICKET_LIST]</ul>
<strong><?php _e('Questions & Answers', 'event_espresso'); ?></strong>
<ul>[QUESTION_LIST]</ul>
<hr />
